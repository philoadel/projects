import React from "react";

const Issue =(props)=>{
    return (<div className="review-container">
    <p>{props.issue}</p>
    
    
    </div>);

};
export default Issue;