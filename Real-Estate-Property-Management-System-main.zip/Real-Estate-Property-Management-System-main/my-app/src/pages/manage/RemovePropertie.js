import React from "react";

const Remove =()=>{
    return (<div className="review-container">
    <p>Remove</p>
    
    
    </div>);

};
export default Remove;