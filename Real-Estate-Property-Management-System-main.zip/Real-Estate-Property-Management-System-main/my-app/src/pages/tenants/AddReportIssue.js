import React from "react";

const AddReportIssue =()=>{
    return (<div className="review-container">
    <p>AddReportIssue</p>
    
    
    </div>);

};
export default AddReportIssue;