import React from "react";

const Print =()=>{
    return (<div className="review-container">
    <p>Print</p>
    
    
    </div>);

};
export default Print;