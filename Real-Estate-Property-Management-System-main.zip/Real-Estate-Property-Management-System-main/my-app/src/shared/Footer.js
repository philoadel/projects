import React from "react";
import "../css/Footer.css"
const Footer =()=>{
    return <div className="footer"> All Copyright &copy; reserved to movie app</div>;

};
export default Footer;